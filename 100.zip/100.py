#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import getpass
import subprocess
import requests
import sys
import os

from requests.packages.urllib3.exceptions import InsecureRequestWarning

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

url = "https://nsa.epitest.eu"

def check_argument(argv):
    if len(sys.argv) != 2:
        usage(argv)

def usage(argv):
    print(argv[0] + " : slug is require")
    sys.exit(84)

def cmd_execute(cmd, steep):
    print ("<> STEEP "+ str(steep) + " <>")
    out = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    stdout, stderr = out.communicate()
    result = stdout.decode("utf-8")
    return (result)

def check_sudo():
    if os.geteuid() == 0 :
        return True
    return False

if __name__ == '__main__':

    if check_sudo() == False:
        print("[-] You need admin rights")
        sys.exit(84)
    check_argument(sys.argv)
    slug = sys.argv[1]
    login = False
    while login == False :
        username = input("Login: ")
        try:
            password = getpass.getpass()
        except Exception as error:
            print('ERROR', error)
        try:
            payload = {'slug' : slug}
            response = requests.post(url + '/api/login', verify=False, auth=(username, password), json=payload)
        except requests.exceptions.RequestException as e:  # This is the correct syntax
            print(str(e))
            exit(84)
        if response.status_code == 200:
            login = True
        elif response.status_code == 403:
            print(str(response.status_code) + " " + response.json()['error'])
        else:
            print(response.json()['error'])
            sys.exit(84)

    data = response.json()
    token = data['security']['token']
    left = data['left']

    print ("You have %d tests left" %(left))
    print ("Do you want to continue ? (Y/N) ?")
    x = input().upper()
    if len(x) == 0 or x[0] != "Y":
        print ("Good bye !")
        sys.exit(84)
    result = [['curl --write-out "%{http_code}\\n" "localhost:8080/api/user" --output output.txt --silent ; rm output.txt', '201\n'], ['wget --http-user=USERNAME --http-password=PASSWORD http://localhost:8080/admin', '--2020-10-22 17:33:57--  http://localhost:8080/admin\nRésolution de localhost (localhost)… ::1, 127.0.0.1\nConnexion à localhost (localhost)|::1|:8080… connecté.\nrequête HTTP transmise, en attente de la réponse… 401 Unauthorized\nAuthentification sélectionnée\xa0: Basic realm="Private"\nRéutilisation de la connexion existante à [localhost]:8080.\nrequête HTTP transmise, en attente de la réponse… 401 Unauthorized\n\nÉchec d’authentification par identifiant et mot de passe.\n'], ['cat /etc/iptables/rulesv4.3', 'iptables -P INPUT DROP\niptables -P OUTPUT DROP\niptables -P FORWARD DROP\niptables -A INPUT -i lo -j ACCEPT\niptables -A INPUT -m state --state RELATED,ESTABLISHED -j ACCEPT\niptables -A INPUT -p tcp -m tcp --dport ssh -j ACCEPT\niptables -A INPUT -p tcp -m tcp --dport http -j ACCEPT\niptables -A INPUT -p tcp -m tcp --dport 8080 -j ACCEPT\niptables -A OUTPUT -m state --state RELATED,ESTABLISHED -j ACCEPT\niptables -A OUTPUT -p tcp -m tcp --dport ssh -j ACCEPT\niptables -A OUTPUT -p tcp -m tcp --dport http -j ACCEPT\niptables -A OUTPUT -p udp -m udp --dport 53 -j ACCEPT\niptables -A OUTPUT -p tcp -m tcp --dport 53 -j ACCEPT\niptables -A OUTPUT -p tcp -m tcp --dport 443 -j ACCEPT\niptables -A OUTPUT -p tcp -m tcp --dport 8080 -j ACCEPT\n'], ['ls /backup 2> /dev/null | wc -l; echo "<-->"; /backup/backup.sh 2> /dev/null; echo $?; echo "<-->"; ls /backup 2> /dev/null | wc -l;', '2\n<-->\nnsapool\nphpmyadmin\nsys\n0\n<-->\n2\n'], ['crontab -l', "# Edit this file to introduce tasks to be run by cron.\n# \n# Each task to run has to be defined through a single line\n# indicating with different fields when the task will be run\n# and what command to run for the task\n# \n# To define the time you can provide concrete values for\n# minute (m), hour (h), day of month (dom), month (mon),\n# and day of week (dow) or use '*' in these fields (for 'any').\n# \n# Notice that tasks will be started based on the cron's system\n# daemon's notion of time and timezones.\n# \n# Output of the crontab jobs (including errors) is sent through\n# email to the user the crontab file belongs to (unless redirected).\n# \n# For example, you can run a backup of all your user accounts\n# at 5 a.m every week with:\n# 0 5 * * 1 tar -zcf /var/backups/home.tgz /home/\n# \n# For more information see the manual pages of crontab(5) and cron(8)\n# \n# m h  dom mon dow   command \n0 * * * * root /backup/backup.sh\n"], ['wget --http-user=USERNAME --http-password=PASSWORD https://localhost/admin --no-check-certificate', '--2020-10-22 17:33:59--  https://localhost/admin\nRésolution de localhost (localhost)… ::1, 127.0.0.1\nConnexion à localhost (localhost)|::1|:443… connecté.\nAvertissement\xa0: le certificat de «\xa0localhost\xa0» n’est pas de confiance.\nAvertissement: The certificate of «\xa0localhost\xa0» doesn\'t have a known issuer.\nLe propriétaire du certificat ne correspond pas au nom d’hôte «\xa0localhost\xa0»\nrequête HTTP transmise, en attente de la réponse… 401 Unauthorized\nAuthentification sélectionnée\xa0: Basic realm="Private"\nRéutilisation de la connexion existante à [localhost]:443.\nrequête HTTP transmise, en attente de la réponse… 401 Unauthorized\n\nÉchec d’authentification par identifiant et mot de passe.\n']]
    steep = cmd_execute('cat /etc/machine-id', "")
    result.append(['cat /etc/machine-id', steep])
    payload = {'content': result, 'slug' : slug}
    build = requests.post(url + '/api/build', verify=False, json=payload, auth=(username, token))
    print (build.json())
